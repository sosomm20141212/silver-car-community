import React from 'react';

function ChargeCenter() {
  return (
    <div>
      <h2>충전소에 관한 상세 정보</h2>
    </div>
  );
}

export default ChargeCenter;