import React, { useState, useEffect } from "react";
import './Ranking.css';

function Ranking() {
    const images = [
        '/images/PF2K_1등.jpg',
        '/images/PF6_2등.jpg',
        '/images/S-450_3등.jpg',
        '/images/S-3500_4등.jpg',
        '/images/YL500s_5등.jpg',
        '/images/나드리100_6등.jpg',
        '/images/나드리110_7등.jpg',
        '/images/나드리200_8등.jpg',
        '/images/나드리210_9등.jpg',
        '/images/나드리500_10등.jpg',
    ];

    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
        }, 500);

        return () => clearInterval(timer);
    }, [currentIndex, images.length]);

    return (
        <div className="animation-container">
            <div className={`image-container ${currentIndex === 0 ? 'active' : 'inactive'}`}>
                <img
                    className="main-image"
                    src={process.env.PUBLIC_URL + images[0]}
                    alt={`Image 1`}
                />
                <div className={`image-info ${currentIndex === 0 ? 'active' : 'inactive'}`}>
                    <p>1등 정보</p>
                    {/* 다른 정보를 표시하려면 여기에 추가 */}
                </div>
            </div>

            {[1, 2, 3].map((groupIndex) => (
                <div
                    key={groupIndex}
                    className={`image-container ${
                        currentIndex > (groupIndex - 1) * 3 &&
                        currentIndex <= groupIndex * 3
                            ? 'active'
                            : 'inactive'
                    }`}
                >
                    {images
                        .slice(groupIndex * 3 - 2, groupIndex * 3 + 1)
                        .map((image, index) => (
                            <div key={index + groupIndex * 3 - 1} className={`sub-image-container ${index === (currentIndex - groupIndex * 3 + 1) % 3 ? 'active' : 'inactive'}`}>
                                <img
                                    className={`sub-image ${index === (currentIndex - groupIndex * 3 + 1) % 3 ? 'active' : 'inactive'}`}
                                    src={process.env.PUBLIC_URL + image}
                                    alt={`Image ${index + groupIndex * 3}`}
                                />
                                <div className={`image-info ${index === (currentIndex - groupIndex * 3 + 1) % 3 ? 'active' : 'inactive'}`}>
                                    <p>{`${index + groupIndex * 3 -1}등 정보`}</p>
                                
                                </div>

                                {index + groupIndex * 3 - 1 === 2 && (
                                <div>
                                    {`짱짱`}
                                </div>
                                )}
                            </div>
                        ))}
                </div>
            ))}
        </div>
    );
}

export default Ranking;