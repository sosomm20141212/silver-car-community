import React from 'react';

function SearchCarDetail() {
  return (
    <div>
      <h2>차량에 관한 상세 정보</h2>
    </div>
  );
}

export default SearchCarDetail;