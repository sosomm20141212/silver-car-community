import React, {useState, useEffect} from 'react';
import Header from './Header';
import Footer from './Footer';
import Menu from './Menu';



function Layout({ children }) {

    return (
        <React.Fragment>
          <Header />
          
          <a href="/"><img src='./silvermotion.png' alt='silvermotion'></img></a>
          <Menu />
          {children}
          <Footer />
        </React.Fragment>
      );
    }
    
export default Layout;