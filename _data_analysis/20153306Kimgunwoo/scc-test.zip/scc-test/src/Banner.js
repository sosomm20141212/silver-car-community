import React, { useState, useEffect } from 'react';

const Banner = () => {
  const [imgIndex, setImgIndex] = useState(0);
  const images = [
    '/banners/안전수칙1.png',
    '/banners/안전수칙2.png',
    '/banners/안전수칙3.png',
    '/banners/안전수칙4.png',
    '/banners/안전수칙5.png',
  ];

  useEffect(() => {
    const intervalId = setInterval(nextImage, 3000);

    return () => {
      clearInterval(intervalId);
    };
  }, [imgIndex]);

  const nextImage = () => {
    setImgIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const prevImage = () => {
    setImgIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  return (
    <div className="banner-container">
      <button onClick={prevImage} className="nav-button">
        Previous
      </button>
      <img src={images[imgIndex]} alt={`Image ${imgIndex + 1}`} className="banner-image" />
      <button onClick={nextImage} className="nav-button">
        Next
      </button>
    </div>
  );
};

export default Banner;