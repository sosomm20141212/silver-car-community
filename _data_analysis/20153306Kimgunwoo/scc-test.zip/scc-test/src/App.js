import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Layout from './Layout';
import Search from './Search';
import Subsidy from './Subsidy';
import Ranking from './Ranking';
import Banner from './Banner';
import Login from './Login';
import CheckSubsidy from './CheckSubsidy';
import SearchCarDetail from './SearchCarDetail';
import SaleCompany from './SaleCompany';
import ChargeCenter from './ChargeCenter';
import FreePosting from './FreePosting';

function App() {
  return (
    <Router>
      <Routes>
        <Route
          path='/*'
          element={
            <Layout>
              <Routes>
                <Route
                  index
                  element={
                    <>
                      <Search />
                      <Ranking />
                      <Banner />
                      <Subsidy />
                    </>
                  }
                />
                <Route path='/search_car_detail' element={<SearchCarDetail />} />
                <Route path='/sale_company' element={<SaleCompany />} />
                <Route path='/charge_center' element={<ChargeCenter />} />
                <Route path='/free_posting' element={<FreePosting />} />
                <Route path='/check_subsidy' element={<CheckSubsidy />} />
              </Routes>
            </Layout>
          }
        />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;