import React from 'react';

function SaleCompany() {
  return (
    <div>
      <h2>판매 업체 정보</h2>
    </div>
  );
}

export default SaleCompany;