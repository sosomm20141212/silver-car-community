import React from 'react';
import Register from '../components/Register.js';

function showRegister() {
  return (
    <div>
      <h2>회원가입 페이지 로딩</h2>
        <Register/>
    </div>
  );
}

export default showRegister;