package com.kepco.silver_car_community.silvercarcommunity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SilverCarCommunityApplicationTests {

	@Test
	void contextLoads() {
	}

}
