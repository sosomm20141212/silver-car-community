import React from 'react';
import Store from '../components/Store.js';
function SaleCompany() {
  return (
    <div>
      {/* <h2>판매 업체 정보</h2> */}
      <Store/>
    </div>
  );
}

export default SaleCompany;