import React from 'react';
import ProductList from '../components/ProductList';
function SearchCarDetail() {
  return (
    <div>
      {/* <h2>모델에 관한 상세 정보</h2> */}
      <ProductList></ProductList>
    </div>
  );
}

export default SearchCarDetail;