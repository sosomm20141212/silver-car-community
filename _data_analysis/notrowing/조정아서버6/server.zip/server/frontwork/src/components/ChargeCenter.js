import React from 'react';
import Station from '../components/Station.js';
function ChargeCenter() {
  return (
    <div>
      {/* <h2>충전소에 관한 상세 정보</h2> */}
      <Station/>
    </div>
  );
}

export default ChargeCenter;