import React from 'react';

function FreePosting() {
  return (
    <div>
      <h2>게시판</h2>
    </div>
  );
}

export default FreePosting;