import React from 'react';

function CheckSubsidy() {
  return (
    <div>
      <h2>나의 보조금 확인</h2>
      <h3>왜아무것도안되냐고 ㅠㅠ</h3>
    </div>
  );
}

export default CheckSubsidy;